package blc;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

class ResponseCodeRunnable implements Runnable {
	private Thread t;
	private List<String> linkList;
	private FileWriter outputFile;

	private static int counter = 1;
	private static int total = 0;

	public ResponseCodeRunnable(List<String> linkList, FileWriter outputFile, int total) {
		this.linkList = linkList;
		this.outputFile = outputFile;
		ResponseCodeRunnable.total = total;
	}

	public void run() {
		int code = 404;

		for (int i = 0; i < linkList.size(); i++) {
			code = getResponseCode(linkList.get(i));
			System.out.println("(" + (counter++) + "/" + ResponseCodeRunnable.total + ") " + linkList.get(i)
					+ "\nResponse code is: " + code + "\n");

			if (!((code == 404) || (code == 505))) {
				try {
					outputFile.write(linkList.get(i) + "\t" + code + "\tYes\n");
					outputFile.flush();
				} catch (IOException e) {
					System.out.println("ERROR: " + e.getMessage());
				}
			} else {
				try {
					outputFile.write(linkList.get(i) + "\t" + code + "\tNO\n");
					outputFile.flush();
				} catch (IOException e) {
					System.out.println("ERROR: " + e.getMessage());
				}
			}
		}
	}

	private static int getResponseCode(String currentURL) {
		int code = 404;

		try {
			// Create a trust manager that does not validate certificate chains
			TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
				public java.security.cert.X509Certificate[] getAcceptedIssuers() {
					return null;
				}

				public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {
				}

				public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {
				}
			} };

			// Try installing the all-trusting trust manager
			SSLContext sc = SSLContext.getInstance("SSL");
			sc.init(null, trustAllCerts, new java.security.SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

			// Try Https connection without having the certificate in
			// the truststore
			URL url = new URL(currentURL);
			HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
			connection.setRequestMethod("GET");
			connection.connect();
			code = connection.getResponseCode();

		} catch (Exception e) {

			// Try a regular Http connection
			try {
				URL url = new URL(currentURL);
				HttpURLConnection connection = (HttpURLConnection) url.openConnection();
				connection.setRequestMethod("GET");
				connection.connect();
				code = connection.getResponseCode();
			} catch (Exception e2) {
//				System.out.println("ERROR: " + e2.getMessage());
			}
		}

		return code;
	}

	public void start() {
		if (t == null) {
			t = new Thread(this);
			t.start();
		}
	}
}

class ShutdownHook extends Thread {
	FileWriter outputFile;

	public ShutdownHook(FileWriter outputFile) {
		this.outputFile = outputFile;
	}

	public void run() {
		try {
			outputFile.close();
			System.out.println("\n---------------");
			System.out.println("Scan Complete");
			System.out.println("Check xls file for search results");
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}
}

public class BLCv3 {
	public static void main(String[] args) {

		String foldername = "";
		File newFolder = null;
		FileWriter outputFile = null;
		DateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy");
		Calendar cal = Calendar.getInstance();
		Scanner input = new Scanner(System.in);

		List<String> linkList = new ArrayList<String>();
		Set<String> linkSet = new HashSet<String>();
		String currentPage = "http://www.cooperators.ca/";
		String pageOnlyAns = "";

		// Asking for URL
		System.out.println("Welcome to The Co-operators Broken Link Checker!");
		System.out.print("Enter URL Address: ");
		currentPage = input.nextLine();
		System.out.print("One page only (Y/N): ");
		pageOnlyAns = input.nextLine();
		input.close();

		// Create folder + results file
		foldername = currentPage.split("/")[2] + "_" + dateFormat.format(cal.getTime()) + ".xls";
		newFolder = new File(foldername);
		newFolder.mkdir();
		try {
			outputFile = new FileWriter(foldername + "\\results.xls");
			outputFile.write("URL\tResponse Code\tValid?\n");
		} catch (IOException e) {
			System.out.println("ERROR: " + e.getMessage());
		}

		// Starts page by adding the input page
		System.out.println("\nInitiating link scan:");
		linkList.add(currentPage);

		// Scanning for all links
		for (int i = 0; i < linkList.size(); i++) {
			System.out.println("Scanning... (" + (i + 1) + "/" + linkList.size() + ")\t\t" + linkList.get(i));
			try {
				getPageLinks(linkList, linkSet, currentPage.split("/")[0] + "//" + currentPage.split("/")[2],
						linkList.get(i), pageOnlyAns);
			} catch (Exception e) {
				System.out.println("ERROR: " + e.getMessage() + "\n");
			}
		}

		linkSet.addAll(linkList);
		linkList.clear();
		linkList.addAll(linkSet);

		// Response code scan
		System.out.println("\n---------------");
		System.out.println("Initiating response code scan (" + linkList.size() + " links):");
		List<List<String>> parts = chopped(linkList, 20);

		Runtime.getRuntime().addShutdownHook(new ShutdownHook(outputFile));
		ResponseCodeRunnable[] linkScanner = new ResponseCodeRunnable[parts.size()];
		for (int i = 0; i < parts.size(); i++) {
			linkScanner[i] = new ResponseCodeRunnable(parts.get(i), outputFile, linkList.size());
			linkScanner[i].start();
		}
	}

	private static void getPageLinks(List<String> linkList, Set<String> linkSet, String originalDomain,
			String currentPage, String pageOnlyAns) throws Exception {
		Document doc = Jsoup.connect(currentPage).userAgent("Mozilla").timeout(10000).get();
		Elements links = doc.select("a[href]");

		String currentUrl = "";

		for (int i = 0; i < links.size(); i++) {
			currentUrl = links.get(i).toString().split("href=\"")[1];
			currentUrl = currentUrl.split("\"")[0];

			if (currentUrl.indexOf("//") == 0) {
				currentUrl = currentUrl.substring(2);
			} else if (currentUrl.indexOf("/") == 0) {
				currentUrl = originalDomain + currentUrl;
			}

			if (isValidLink(currentUrl)) {
				if (!(currentUrl.indexOf("http") == 0 || currentUrl.indexOf("https") == 0)) {
					currentUrl = "http://" + currentUrl;
				}
			}

			if (!linkList.contains(currentUrl) && !(currentUrl.toLowerCase().contains("javascript:")
					|| currentUrl.toLowerCase().contains("mailto:") || currentUrl.toLowerCase().contains("tel:")
					|| currentUrl.length() <= 1 || currentUrl.length() > 0 && currentUrl.charAt(0) == '#')) {
				linkSet.add(currentUrl);

				if (currentUrl.contains(originalDomain) && isValidLink(currentUrl)
						&& (pageOnlyAns.equalsIgnoreCase("n") || pageOnlyAns.equalsIgnoreCase("no"))) {
					linkList.add(currentUrl);
				}
			}
		}
	}

	private static boolean isValidLink(String currentPage) {
		return !(currentPage.toLowerCase().contains("javascript:") || currentPage.toLowerCase().contains("mailto:")
				|| currentPage.toLowerCase().contains("tel:") || currentPage.toLowerCase().contains(".pdf")
				|| currentPage.toLowerCase().contains(".zip") || currentPage.toLowerCase().contains(".docx")
				|| currentPage.toLowerCase().contains(".jpg") || currentPage.toLowerCase().contains(".jpeg")
				|| currentPage.toLowerCase().contains(".png") || currentPage.toLowerCase().contains(".gif")
				|| currentPage.toLowerCase().contains(".ashx") || currentPage.toLowerCase().contains(".eps")
				|| currentPage.length() <= 1 || currentPage.length() > 0 && currentPage.charAt(0) == '#');
	}

	private static <T> List<List<T>> chopped(List<T> list, final int L) {
		List<List<T>> parts = new ArrayList<List<T>>();
		final int N = list.size();
		for (int i = 0; i < N; i += L) {
			parts.add(new ArrayList<T>(list.subList(i, Math.min(N, i + L))));
		}

		return parts;
	}
}
