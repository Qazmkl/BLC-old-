/****************************************************
* Name: Broken Link Checker v3
* Author: Timothy Agda
* Date: 06/10/16
****************************************************/

Notes:
- Project made in Eclipse
- Uses JSoup to parse document
- Uses threads (runnables)
- Outputs to xls file


To RUN (Eclipse):
- Open project through Eclipse
- Press F11

To RUN (CMD or Terminal):
- Open Command Prompt or Terminal
- Change directory to folder with BLCv2.jar
- Enter: java -jar BLCv2.jar
- Press 'enter'

References:
http://www.software-testing-tutorials-automation.com/2015/08/how-to-find-broken-linksimages-from.html
http://stackoverflow.com/questions/1201048/allowing-java-to-use-an-untrusted-certificate-for-ssl-https-connection
http://stackoverflow.com/questions/2895342/java-how-can-i-split-an-arraylist-in-multiple-small-arraylists
